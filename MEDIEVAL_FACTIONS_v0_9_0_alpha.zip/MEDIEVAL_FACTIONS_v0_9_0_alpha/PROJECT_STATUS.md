# Estado del proyecto — MEDIEVAL FACTIONS v0.9.0-alpha

## Resumen de versión

v0.9 es una actualización de corrección e integración incremental; no declara completo el mod.

v0.8 añade una capa común de simulación para las nueve áreas que seguían abiertas en v0.7: IA de habitantes, construcción urbana, táctica, convoyes, ejército abstracto, dragones, familia/medicina, jefes y expediciones. Parte de los flujos ya afecta a entidades, inventarios y ubicaciones reales. No se presenta como mod completo ni como build certificado.

## Cambios específicos de v0.9

- Runtime de ticks/minutos aislado por instancia de `MinecraftServer`.
- Expediciones físicas con exclusividad de miembros y liberación al completar o fallar.
- Límites defensivos para registros NBT avanzados y tolerancia a registros individuales corruptos.
- Guardias y dragones sin jinete con combate melee básico contra monstruos hostiles.
- CI configurada para publicar el JAR como artefacto solo si el build de Gradle y las pruebas pasan.

Estos cambios estabilizan y amplían la base; no completan la simulación social, las interfaces gráficas, las ciudades integrales ni la guerra visual.

## Sistemas heredados de v0.8

- **Habitantes:** horarios diarios, directivas de supervivencia, destinos y enlaces persistentes entre ciudadano y `MFResidentEntity`; el NPC usa `PathNavigation` terrestre vanilla. Se añade A* 3D acotado como motor puro, aún no conectado al navegador del mundo.
- **Ciudad:** parcelas, distritos, validación de límites/solapamiento, reserva de materiales y enlace al proceso físico de construcción. Los blueprints reales siguen limitados a `small_house` y `watchtower`.
- **Guerra táctica:** unidades abstractas, órdenes MOVE/ATTACK/BLOCK/DODGE/RALLY/RETREAT, formaciones, turnos, columnas logísticas y ocupación persistente. No crea soldados visibles todavía.
- **Caravanas:** convoyes físicos simulados por waypoints, mercancía y escrow reservados, emboscadas, carga perdida, reanudación y liquidación bilateral. No hay carro ni escolta como entidades.
- **Dragones:** genoma, herencia determinista, huevos, incubación, eclosión y enlace a Companion/entidad Dragon. Las crías todavía no tienen crecimiento visual completo ni IA aérea autónoma.
- **Familia:** propuesta/respuesta de matrimonio, divorcio y reglas de relación/consentimiento. Se conservan gestación, nacimiento y linaje.
- **Medicina:** clínicas ligadas a asentamiento, DOCTOR activo, camas y pociones reales; los tratamientos consumen una poción y la simulación diaria contempla alimentación/seguridad.
- **Expediciones:** rutas por waypoints que dirigen NPC materializados en la dimensión actual. El waypoint solo avanza cuando todos los integrantes cargados alcanzan físicamente su destino; la simulación diaria consume provisiones y resuelve riesgos.
- **Mazmorras/jefes:** motor de encuentros con fases y telegráficos. La mazmorra física sigue usando encuentros básicos; el boss abstracto no está enlazado todavía a una entidad de jefe única.

## Integraciones y comandos nuevos

- `/mf advanced npc spawn|schedule|plan|list`
- `/mf advanced city plan|build|list`
- `/mf advanced caravan physical|resume|list-physical`
- `/mf advanced companion genome|breed|incubate|hatch`
- `/mf advanced family marriage propose|answer|divorce`
- `/mf advanced family clinic register|open|treat`
- `/mf advanced expedition route`

Los parámetros exactos y precondiciones se describen en `README_ES.md`.

## Base heredada

- Minecraft Java 1.21.1, NeoForge 21.1.267, Java 21, GeckoLib 4.9.4.
- Perfiles, razas, clases, profesiones, árboles data-driven, calendario, facciones, asentamientos, economía, producción, banca, préstamos, comercio y diplomacia inicial.
- Recursos y entidades prototipo de versiones anteriores.

## Límites que siguen abiertos

- GUI gráfica real (pantallas y menús cliente-servidor).
- Agentes NPC completos: pathfinding de mundo integrado con A*, selección autónoma de trabajo, tareas de campo, relaciones y vida social.
- Constructor de ciudad integral, editor fantasma, servicios y edificios especializados.
- Árbol completo de habilidades y táctica conectada a soldados visibles.
- Carros, escoltas, mercado autónomo y economía global.
- Ejércitos visibles, máquinas de asedio y captura de territorio jugable.
- Vuelo autónomo dracónico, crecimiento visual y reproducción natural con hábitat/temperatura.
- Matrimonio y medicina desde interacciones normales de NPC, embarazo/parto visual y vida familiar completa.
- Jefes físicos únicos sincronizados con su motor de encuentros y expediciones robustas con chunks/dimensiones y rescate.

## Validación ejecutada

- `tools/run_domain_tests.sh`: 136 núcleo + 74 sistemas avanzados + 61 expansión = **271 aserciones superadas**.
- `tools/run_saveddata_stub_tests.sh`: PASS, smoke test limitado a un subconjunto anterior de SavedData.
- `python tools/validate_assets.py`: 106 JSON, 14 rigs, 75 SoundEvents y 75 OGG; 0 errores/advertencias.
- Auditoría `javac` sin classpath de Minecraft: no concluyente porque faltan paquetes y tipos externos; no es compilación ni type-check de todo el proyecto.

## No verificado

- Gradle y Gradle Wrapper no están disponibles en el entorno; la red/DNS no permitió descargar dependencias.
- No se ejecutaron `gradle clean test build`, `runClient`, `runServer`, GameTests, persistencia de Minecraft real ni multijugador.
- No se ha generado ni certificado un JAR.

**Dictamen:** v0.9 corrige aislamiento de runtime, doble asignación de expediciones y límites defensivos de persistencia; añade combate autónomo básico a guardias y dragones. No finaliza todavía las nueve mecánicas. La matriz de cobertura y el plan técnico mantienen explícitos los bloques pendientes.
