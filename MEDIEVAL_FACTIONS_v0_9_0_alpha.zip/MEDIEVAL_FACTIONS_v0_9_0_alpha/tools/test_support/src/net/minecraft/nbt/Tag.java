package net.minecraft.nbt;
public interface Tag { int TAG_COMPOUND = 10, TAG_STRING = 8, TAG_LONG = 4; }
