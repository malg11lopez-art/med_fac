#!/usr/bin/env python3
"""Static checks for MEDIEVAL FACTIONS resources. Does not replace an in-game test."""
from pathlib import Path
import json, re, sys, wave, subprocess
from PIL import Image
ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "src/main/resources/assets/medieval_factions"
errors=[]; warnings=[]
def read(p):
    try: return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"JSON inválido {p.relative_to(ROOT)}: {e}"); return {}
# all JSON resources parse
json_files=list(ASSETS.rglob("*.json")) + list((ROOT/"src/main/resources/data").rglob("*.json"))
for p in json_files: read(p)
# geo bones and animation references
geos={}
for p in (ASSETS/"geo").rglob("*.geo.json"):
    d=read(p); names=set()
    for geometry in d.get("minecraft:geometry",[]):
        names.update(b.get("name") for b in geometry.get("bones",[]) if b.get("name"))
    geos[p.name.removesuffix(".geo.json")]=names
mapping={"guard":"guard","guard_combat":"guard","guard_magic":"guard","guard_professions":"guard","horse":"horse","dragon":"dragon"}
special={"centaur":"centaur","harpy":"harpy","merfolk":"merfolk","draconid":"draconid","wolf":"wolf","griffin":"griffin","phoenix":"phoenix"}
for p in (ASSETS/"animations/entities").glob("*.animation.json"):
    d=read(p)
    if p.stem in mapping:
        target=mapping[p.stem]
        for aname, anim in d.get("animations",{}).items():
            missing=set(anim.get("bones",{}))-geos.get(target,set())
            if missing: errors.append(f"{aname}: huesos inexistentes en {target}: {sorted(missing)}")
    if p.stem == "special_entities":
        for aname, anim in d.get("animations",{}).items():
            group=aname.split('.')[1]
            target=special.get(group)
            if target:
                missing=set(anim.get("bones",{}))-geos.get(target,set())
                if missing: errors.append(f"{aname}: huesos inexistentes en {target}: {sorted(missing)}")
# block animation bone check
block_map={'forge':'forge','arcane_workbench':'arcane_workbench','royal_banner':'royal_banner','windmill':'windmill'}
for p in (ASSETS/"animations/blocks").glob("*.animation.json"):
    d=read(p)
    for aname, anim in d.get("animations",{}).items():
        target=next((k for k in block_map if aname.startswith('animation.'+k+'.')),None)
        if target:
            missing=set(anim.get('bones',{}))-geos.get(target,set())
            if missing: errors.append(f"{aname}: huesos inexistentes en {target}: {sorted(missing)}")
# sound file refs and keyframe refs
sounds=read(ASSETS/"sounds.json")
for event, definition in sounds.items():
    for item in definition.get('sounds',[]):
        name=item if isinstance(item,str) else item.get('name','')
        ns, path=(name.split(':',1) if ':' in name else ('minecraft',name))
        if ns=='medieval_factions' and not (ASSETS/'sounds'/f'{path}.ogg').exists():
            errors.append(f"Sonido {event}: falta {path}.ogg")
for p in (ASSETS/"animations").rglob("*.animation.json"):
    d=read(p)
    for aname, anim in d.get('animations',{}).items():
        for marker in anim.get('sound_effects',{}).values():
            sid=marker.get('effect','').split('|')[0]
            ns, path=(sid.split(':',1) if ':' in sid else ('minecraft',sid))
            if ns=='medieval_factions' and path not in sounds:
                errors.append(f"Keyframe {aname}: SoundEvent inexistente {sid}")
# Minecraft 1.21+ singular data folder checks.
for required_tag in [ROOT/"src/main/resources/data/minecraft/tags/block/mineable/pickaxe.json", ROOT/"src/main/resources/data/minecraft/tags/block/needs_iron_tool.json"]:
    if not required_tag.exists():
        errors.append(f"Falta tag 1.21.x: {required_tag.relative_to(ROOT)}")
for recipe in (ROOT/"src/main/resources/data/medieval_factions/recipe").glob("*.json"):
    read(recipe)

# Java renderer resource references and sound registration parity.
java_root = ROOT / "src/main/java"
for source in java_root.rglob("*.java"):
    text = source.read_text(encoding="utf-8")
    # Model classes use namespace-relative paths in ResourceLocation.fromNamespaceAndPath.
    if source.name.endswith("Model.java"):
        for rel in re.findall(r'ResourceLocation\.fromNamespaceAndPath\(MedievalFactions\.MOD_ID, "([^"]+)"\)', text):
            if rel.startswith("textures/"):
                target = ASSETS / (rel if Path(rel).suffix else rel + ".png")
            else:
                target = ASSETS / rel
            if not target.exists():
                errors.append(f"Renderer {source.name}: falta recurso {rel}")
registry = java_root / "com/medievalfactions/registry/MFSounds.java"
if registry.exists():
    registered = set(re.findall(r'SOUND_EVENTS\.register\("([a-z0-9_]+)"', registry.read_text(encoding="utf-8")))
    for event in sounds:
        if event not in registered:
            errors.append(f"SoundEvent sin DeferredRegister: {event}")
    for event in registered:
        if event not in sounds:
            errors.append(f"Deferred SoundEvent sin sounds.json: {event}")

# textures decode
for p in ASSETS.rglob('*.png'):
    try:
        with Image.open(p) as im:
            im.verify()
    except Exception as e: errors.append(f"PNG corrupto {p.relative_to(ROOT)}: {e}")
# model texture references
for p in (ASSETS/'models').rglob('*.json'):
    d=read(p)
    for val in d.get('textures',{}).values():
        if ':' not in val: continue
        ns,path=val.split(':',1)
        if ns=='medieval_factions' and not (ASSETS/'textures'/f'{path}.png').exists():
            errors.append(f"Modelo {p.name}: falta textura {val}")

# Item/block model parent checks and all locale keys.
for p in (ASSETS/"models").rglob("*.json"):
    d=read(p)
    parent=d.get("parent", "")
    if parent.startswith("medieval_factions:"):
        rel=parent.split(":",1)[1]
        candidates=[ASSETS/"models"/(rel+".json")]
        if not any(c.exists() for c in candidates):
            warnings.append(f"Parent custom no encontrado (puede ser modelo vanilla): {p.relative_to(ROOT)} -> {parent}")
# Check texture paths in geo models.
for p in (ASSETS/"geo").rglob("*.geo.json"):
    d=read(p)
    for geometry in d.get("minecraft:geometry", []):
        desc=geometry.get("description", {})
        tw, th=desc.get("texture_width"), desc.get("texture_height")
        if not isinstance(tw, int) or not isinstance(th, int):
            errors.append(f"Geo sin dimensiones de textura válidas: {p.relative_to(ROOT)}")

# Required translation keys for every registered item and block model.
try:
    es = read(ASSETS/"lang/es_es.json")
    for model in (ASSETS/"models/item").glob("*.json"):
        item = model.stem
        if f"item.medieval_factions.{item}" not in es and f"block.medieval_factions.{item}" not in es:
            errors.append(f"Falta traducción es_es para modelo de objeto: {item}")
    for state in (ASSETS/"blockstates").glob("*.json"):
        block = state.stem
        if f"block.medieval_factions.{block}" not in es:
            errors.append(f"Falta traducción es_es para bloque: {block}")
except Exception as ex:
    errors.append(f"No se pudieron validar traducciones: {ex}")
# Animation names hard-coded in Java controllers must exist in a GeckoLib animation file.
known_animations=set()
for p in (ASSETS/"animations").rglob("*.animation.json"):
    d=read(p)
    known_animations.update(d.get("animations",{}))
for source in (ROOT/"src/main/java").rglob("*.java"):
    code=source.read_text(encoding="utf-8")
    for clip in set(re.findall(r'"(animation\.[a-z0-9_.]+)"', code)):
        if clip not in known_animations:
            errors.append(f"Controlador Java {source.name}: animación inexistente {clip}")

# OGG metadata check if ffprobe exists
try:
    subprocess.run(['ffprobe','-version'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
    for p in (ASSETS/'sounds').rglob('*.ogg'):
        q=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_name,channels,sample_rate','-of','default=nw=1',str(p)],capture_output=True,text=True)
        if q.returncode: errors.append(f"OGG ilegible: {p.relative_to(ROOT)}")
        else:
            info=q.stdout
            if 'vorbis' not in info: errors.append(f"Codec no Vorbis: {p.relative_to(ROOT)}")
            if 'channels=1' not in info: warnings.append(f"Audio no mono (puede no atenuarse): {p.relative_to(ROOT)}")
except Exception:
    warnings.append('ffprobe no instalado; metadatos OGG no comprobados')
print(f"JSON: {len(json_files)} | Geo rigs: {len(geos)} | SoundEvents: {len(sounds)} | OGG: {len(list((ASSETS/'sounds').rglob('*.ogg')))}")
print(f"Errores: {len(errors)} | Advertencias: {len(warnings)}")
for x in errors: print('ERROR:',x)
for x in warnings: print('WARN:',x)
sys.exit(1 if errors else 0)
