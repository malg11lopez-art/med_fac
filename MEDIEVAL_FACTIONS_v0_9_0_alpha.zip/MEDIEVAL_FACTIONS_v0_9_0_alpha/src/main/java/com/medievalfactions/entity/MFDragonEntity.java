package com.medievalfactions.entity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.RawAnimation;

/** Persistent, owner-bound dragon mount with controlled flight and a server-validated fire breath action. */
public final class MFDragonEntity extends MFAnimatedMob {
    public MFDragonEntity(EntityType<? extends MFDragonEntity> type, Level level) { super(type, level); }
    @Override protected boolean isRideable() { return true; }
    @Override protected boolean isFlyingMount() { return true; }
    @Override protected String idleAnimation() { return "animation.dragon.idle"; }
    @Override protected String walkAnimation() { return "animation.dragon.ground_walk"; }
    @Override protected void registerGoals() {
        super.registerGoals();
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, true) {
            @Override public boolean canUse() {
                return getControllingPassenger() == null && super.canUse();
            }
            @Override public boolean canContinueToUse() {
                return getControllingPassenger() == null && super.canContinueToUse();
            }
        });
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }
    @Override public boolean doHurtTarget(Entity target) {
        triggerAnim("action", "bite");
        return super.doHurtTarget(target);
    }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        addLocomotionController(controllers);
        controllers.add(actionController()
            .triggerableAnim("roar", RawAnimation.begin().thenPlay("animation.dragon.roar"))
            .triggerableAnim("bite", RawAnimation.begin().thenPlay("animation.dragon.bite"))
            .triggerableAnim("breath", RawAnimation.begin().thenPlay("animation.dragon.breath_fire")));
    }
    /** Call on the logical server only after the dragon AI validates the action. */
    public void playRoar() { this.triggerAnim("action", "roar"); }
    public void playBreathAnimation() { this.triggerAnim("action", "breath"); }
}
