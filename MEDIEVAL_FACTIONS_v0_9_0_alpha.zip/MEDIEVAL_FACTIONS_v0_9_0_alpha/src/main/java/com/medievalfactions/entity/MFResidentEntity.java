package com.medievalfactions.entity;

import com.medievalfactions.data.MFAdvancedSavedData;
import com.medievalfactions.domain.MFCitizenSimulation;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animation.AnimatableManager;

import java.util.UUID;

/** Visible resident linked to a persistent citizen record; server plans drive vanilla path navigation. */
public final class MFResidentEntity extends MFAnimatedMob {
    private UUID citizenId;
    private BlockPos lastNavigationTarget;

    public MFResidentEntity(EntityType<? extends MFResidentEntity> type, Level level) { super(type, level); }

    public void bindCitizen(UUID id) {
        if (id == null) throw new IllegalArgumentException("Citizen identity required");
        this.citizenId = id;
        setPersistenceRequired();
    }
    public UUID citizenId() { return citizenId; }

    @Override protected String idleAnimation() { return "animation.guard.idle"; }
    @Override protected String walkAnimation() { return "animation.guard.walk"; }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        addLocomotionController(controllers);
    }

    @Override public void tick() {
        super.tick();
        if (level().isClientSide || citizenId == null || tickCount % 10 != 0 || !(level() instanceof ServerLevel serverLevel)) return;
        var data = MFAdvancedSavedData.get(serverLevel.getServer());
        var plan = data.record("citizen_plans", citizenId, MFCitizenSimulation.CitizenPlan.class).orElse(null);
        if (plan == null) { getNavigation().stop(); lastNavigationTarget = null; return; }
        if (plan.activity() == MFCitizenSimulation.Activity.SOCIALIZE) {
            var neighbours = serverLevel.getEntitiesOfClass(MFResidentEntity.class, getBoundingBox().inflate(8.0D),
                    other -> other != this && other.citizenId != null);
            MFResidentEntity neighbour = neighbours.stream().min(java.util.Comparator.comparingDouble(this::distanceToSqr)).orElse(null);
            if (neighbour != null) getLookControl().setLookAt(neighbour, 10.0F, 40.0F);
        }
        MFCitizenSimulation.Waypoint destination = plan.destination();
        if (!serverLevel.dimension().location().toString().equals(destination.dimension())) {
            getNavigation().stop(); lastNavigationTarget = null; return;
        }
        BlockPos target = new BlockPos(destination.x(), destination.y(), destination.z());
        if (distanceToSqr(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D) <= 2.25D) {
            getNavigation().stop(); lastNavigationTarget = target;
            data.reportResidentWaypointArrival(serverLevel, citizenId);
            return;
        }
        if (!target.equals(lastNavigationTarget) || getNavigation().isDone()) {
            double speed = plan.directive() == MFCitizenSimulation.Directive.FLEE ? 1.25D
                    : plan.directive() == MFCitizenSimulation.Directive.SEEK_MEDIC ? 1.05D : 0.9D;
            getNavigation().moveTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D, speed);
            lastNavigationTarget = target;
        }
    }

    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (citizenId != null) tag.putUUID("mf_citizen_id", citizenId);
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        citizenId = tag.hasUUID("mf_citizen_id") ? tag.getUUID("mf_citizen_id") : null;
        lastNavigationTarget = null;
    }
}
