package com.medievalfactions.entity.model;

import com.medievalfactions.MedievalFactions;
import com.medievalfactions.entity.MFResidentEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

/** Uses the existing guard rig as a temporary resident rig until civilian clothing variants are authored. */
public final class MFResidentModel extends GeoModel<MFResidentEntity> {
    @Override public ResourceLocation getModelResource(MFResidentEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(MedievalFactions.MOD_ID, "geo/entities/guard.geo.json");
    }
    @Override public ResourceLocation getTextureResource(MFResidentEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(MedievalFactions.MOD_ID, "textures/entity/guard.png");
    }
    @Override public ResourceLocation getAnimationResource(MFResidentEntity animatable) {
        return ResourceLocation.fromNamespaceAndPath(MedievalFactions.MOD_ID, "animations/entities/guard.animation.json");
    }
}
