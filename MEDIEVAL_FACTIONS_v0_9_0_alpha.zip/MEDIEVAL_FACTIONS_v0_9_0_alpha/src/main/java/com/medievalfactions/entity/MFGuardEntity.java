package com.medievalfactions.entity;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.RawAnimation;

public final class MFGuardEntity extends MFAnimatedMob {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.guard.idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.guard.walk");
    private static final RawAnimation SLASH = RawAnimation.begin().thenPlay("animation.guard.attack_light");
    private static final RawAnimation BLOCK = RawAnimation.begin().thenPlay("animation.guard.block");
    public MFGuardEntity(EntityType<? extends MFGuardEntity> type, Level level) { super(type, level); }
    @Override protected String idleAnimation() { return "animation.guard.idle"; }
    @Override protected String walkAnimation() { return "animation.guard.walk"; }
    @Override protected void registerGoals() {
        super.registerGoals();
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.10D, true));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }
    @Override public boolean doHurtTarget(Entity target) {
        playSlashAnimation();
        return super.doHurtTarget(target);
    }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        addLocomotionController(controllers);
        controllers.add(actionController()
            .triggerableAnim("slash", SLASH)
            .triggerableAnim("block", BLOCK));
    }
    /** Call on the logical server after validating the combat action. */
    public void playSlashAnimation() { this.triggerAnim("action", "slash"); }
    public void playBlockAnimation() { this.triggerAnim("action", "block"); }
}
