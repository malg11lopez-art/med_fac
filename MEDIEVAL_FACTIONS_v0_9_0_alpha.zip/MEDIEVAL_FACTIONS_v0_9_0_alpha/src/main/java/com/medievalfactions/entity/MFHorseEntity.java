package com.medievalfactions.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.AnimationController;

/** Persistent owner-bound horse mount with ground riding controls and animated mount actions. */
public final class MFHorseEntity extends MFAnimatedMob {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.horse.idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop("animation.horse.walk");
    public MFHorseEntity(EntityType<? extends MFHorseEntity> type, Level level) { super(type, level); }
    @Override protected boolean isRideable() { return true; }
    @Override protected String idleAnimation() { return "animation.horse.idle"; }
    @Override protected String walkAnimation() { return "animation.horse.walk"; }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        addLocomotionController(controllers);
        controllers.add(new AnimationController<>(this, "mount_action", 0, state -> PlayState.STOP)
            .triggerableAnim("rear", RawAnimation.begin().thenPlay("animation.horse.rear"))
            .triggerableAnim("jump", RawAnimation.begin().thenPlay("animation.horse.jump"))
            .setSoundKeyframeHandler(new software.bernie.geckolib.animation.keyframe.event.builtin.AutoPlayingSoundKeyframeHandler<>()));
    }
}
