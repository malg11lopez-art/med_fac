package com.medievalfactions.registry;

import com.medievalfactions.MedievalFactions;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/** First-pass content registry. Profession recipes and modular crafting arrive in later milestones. */
public final class MFItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, MedievalFactions.MOD_ID);
    private static final Map<String, DeferredHolder<Item, Item>> REGISTRY = new LinkedHashMap<>();
    private static final String[] SIMPLE_ITEMS = {
        "adamantite_ingot", "ancient_wood", "arcane_book", "arcane_dust", "arcane_staff",
        "battle_spear", "coin_copper", "coin_gold", "coin_silver", "crossbow_bolt", "fire_potion", "fire_staff", "fishing_rod",
        "glacial_crystal", "greatsword", "healing_potion", "hunter_bow", "ice_staff", "iron_axe",
        "iron_pickaxe", "iron_sword", "leather_roll", "lunar_blade", "mithril_ingot", "moon_dagger",
        "orc_shield", "paladin_shield", "rune_crystal", "shadow_dagger", "smith_hammer", "solar_blade",
        "stone_shovel", "sun_spear", "sunsteel_ingot", "warhammer", "sunsteel_fragment"
    };

    static {
        for (String id : SIMPLE_ITEMS) {
            REGISTRY.put(id, ITEMS.register(id, () -> new Item(new Item.Properties())));
        }
        registerBlockItem("blacksmith_anvil", MFBlocks.BLACKSMITH_ANVIL);
        registerBlockItem("town_hall_brick", MFBlocks.TOWN_HALL_BRICK);
        registerBlockItem("forge_controller", MFBlocks.FORGE_CONTROLLER);
        registerBlockItem("arcane_workbench", MFBlocks.ARCANE_WORKBENCH);
        registerBlockItem("royal_banners", MFBlocks.ROYAL_BANNERS);
        registerBlockItem("windmill", MFBlocks.WINDMILL);
        registerBlockItem("sunsteel_ore", MFBlocks.SUNSTEEL_ORE);
        registerBlockItem("deepslate_sunsteel_ore", MFBlocks.DEEPSLATE_SUNSTEEL_ORE);
    }

    private static void registerBlockItem(String id, Supplier<? extends Block> block) {
        REGISTRY.put(id, ITEMS.register(id, () -> new BlockItem(block.get(), new Item.Properties())));
    }

    public static Map<String, DeferredHolder<Item, Item>> all() {
        return Collections.unmodifiableMap(REGISTRY);
    }

    private MFItems() {}
}
